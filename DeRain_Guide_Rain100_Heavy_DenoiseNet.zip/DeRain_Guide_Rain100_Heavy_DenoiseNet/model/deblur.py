from model.common import Conv , Deconv , ResBlock
import torch.nn as nn
import torch
import torch.nn.functional as F
import torch
import torch.nn as nn
from torch.nn import init
import functools
from torch.optim import lr_scheduler

"""
## CycleISP: Real Image Restoration Via Improved Data Synthesis
## Syed Waqas Zamir, Aditya Arora, Salman Khan, Munawar Hayat, Fahad Shahbaz Khan, Ming-Hsuan Yang, and Ling Shao
## CVPR 2020
## https://arxiv.org/abs/2003.07761
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
import torch
import math
from torch.nn import Module, Sequential, Conv2d, ReLU,AdaptiveMaxPool2d, AdaptiveAvgPool2d, \
    NLLLoss, BCELoss, CrossEntropyLoss, AvgPool2d, MaxPool2d, Parameter, Linear, Sigmoid, Softmax, Dropout, Embedding
from torch.nn import functional as F
from torch.autograd import Variable
torch_ver = torch.__version__[:3]
import torch.nn as nn

def conv(in_channels, out_channels, kernel_size, bias=True, padding=1, stride=1):
    return nn.Conv2d(in_channels, out_channels, kernel_size, padding=(kernel_size // 2), bias=bias, stride=stride)

# #####Gradient Branch#####
class Get_gradient_nopadding(nn.Module):
    def __init__(self):
        super(Get_gradient_nopadding, self).__init__()
        kernel_v = [[0, -1, 0],
                    [0, 0, 0],
                    [0, 1, 0]]
        kernel_h = [[0, 0, 0],
                    [-1, 0, 1],
                    [0, 0, 0]]
        kernel_h = torch.FloatTensor(kernel_h).unsqueeze(0).unsqueeze(0)
        kernel_v = torch.FloatTensor(kernel_v).unsqueeze(0).unsqueeze(0)
        self.weight_h = nn.Parameter(data=kernel_h, requires_grad=False)

        self.weight_v = nn.Parameter(data=kernel_v, requires_grad=False)

    def forward(self, x):
        x_list = []
        for i in range(x.shape[1]):
            x_i = x[:, i]
            x_i_v = F.conv2d(x_i.unsqueeze(1), self.weight_v, padding=1)
            x_i_h = F.conv2d(x_i.unsqueeze(1), self.weight_h, padding=1)
            x_i = torch.sqrt(torch.pow(x_i_v, 2) + torch.pow(x_i_h, 2) + 1e-6)
            x_list.append(x_i)

        x = torch.cat(x_list, dim=1)
        return x

## channel attention modules
class CALayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y


## spatial  attention
class spatial_attn_layer(nn.Module):
    def __init__(self, kernel_size=3):
        super(spatial_attn_layer, self).__init__()
        self.compress = ChannelPool()
        self.spatial = BasicConv(2, 1, kernel_size, stride=1, padding=(kernel_size - 1) // 2, relu=False)

    def forward(self, x):
        # import pdb;pdb.set_trace()
        x_compress = self.compress(x)
        x_out = self.spatial(x_compress)
        scale = torch.sigmoid(x_out)  # broadcasting
        return x * scale
        ##########################################################################

###BasicConv
class BasicConv(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True,
                 bn=False, bias=False):
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding,
                              dilation=dilation, groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_planes, eps=1e-5, momentum=0.01, affine=True) if bn else None
        self.relu = nn.ReLU() if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x

###ChannelPool
class ChannelPool(nn.Module):
    def forward(self, x):
        return torch.cat((torch.max(x, 1)[0].unsqueeze(1), torch.mean(x, 1).unsqueeze(1)), dim=1)

## Dual Attention Block (DAB)
class DAB(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=nn.ReLU(True)):

        super(DAB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)

        self.SA = spatial_attn_layer()  ## Spatial Attention
        self.CA = CALayer(n_feat, reduction)  ## Channel Attention
        self.body = nn.Sequential(*modules_body)
        self.conv1x1 = nn.Conv2d(n_feat * 2, n_feat, kernel_size=1)

    def forward(self, x):
        res = self.body(x)
        sa_branch = self.SA(res)
        ca_branch = self.CA(res)
        res = torch.cat([sa_branch, ca_branch], dim=1)
        res = self.conv1x1(res)
        res += x
        return res

## Recursive Residual Group (RRG)
## Recursive Residual Group (RRG)
class RRG(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction, act, num_dab):
        super(RRG, self).__init__()

        modules_body3=[conv(n_feat, n_feat, 3)]
        self.body3 = nn.Sequential(*modules_body3)
        modules_body5=[conv(n_feat, n_feat, 5)]
        self.body5 = nn.Sequential(*modules_body5)
        modules_body7=[conv(n_feat, n_feat, 7)]
        self.body7 = nn.Sequential(*modules_body7)

        modules_body=[conv(n_feat * 3, n_feat, kernel_size)]
        self.body = nn.Sequential(*modules_body)

        modules_bodyA1 = [DAB(conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=act)]
        self.bodyA1 = nn.Sequential(*modules_bodyA1)

        modules_bodyA3 = [DAB(conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=act)]
        self.bodyA3 = nn.Sequential(*modules_bodyA3)

        modules_bodyA5 = [DAB(conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=act)]
        self.bodyA5 = nn.Sequential(*modules_bodyA5)


    def forward(self, x):
        x1 = self.body3(x);   x3 = self.body5(x);    x5 = self.body7(x)
        A1 = self.bodyA1(x1); A3 = self.bodyA3(x3);  A5 = self.bodyA5(x5);
        res = torch.cat([A1, A3, A5], dim=1)
        res3 = self.body(res)
        res3 += x
        return res3


class DEBLUR(nn.Module):
    def __init__(self ):
        super(DEBLUR, self).__init__()
        n_feats = 64
        kernel_size = 3
        inp_chans = 3

        Feat2 = [conv(inp_chans, n_feats, kernel_size=kernel_size, stride=1),
                 RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2),
                 conv(n_feats,inp_chans, kernel_size=kernel_size, stride=1)]
        self.Feature2 = nn.Sequential(*Feat2)


        FeatureBlock = [conv(inp_chans, n_feats, kernel_size=kernel_size, stride=1),
                        RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2),
                        RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2)]
        self.FeatureBlock = nn.Sequential(*FeatureBlock)

        InBlock1 = [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                   RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2),
                   RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2)]
        self.inBlock1 = nn.Sequential(*InBlock1)
        InBlock2 = [conv(n_feats*2, n_feats, kernel_size=kernel_size, stride=1),
                   RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2),
                   RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2)]
        self.inBlock2 = nn.Sequential(*InBlock2)


        # encoder1
        Encoder_first= [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                        RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2),
                        RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2)]
        self.encoder_first = nn.Sequential(*Encoder_first)

        # encoder2
        Encoder_second = [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                          RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2),
                          RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2)]
        self.encoder_second = nn.Sequential(*Encoder_second)

        # encoder3
        Encoder_third = [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                          RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2),
                          RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2)]
        self.encoder_third = nn.Sequential(*Encoder_third)

        # encoder4
        Encoder_fourth = [conv(n_feats, n_feats, kernel_size=kernel_size, stride=1),
                          RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2),
                          RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2)]
        self.encoder_fourth = nn.Sequential(*Encoder_fourth)


        OutBlock = [RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2),
                    RRG(conv, 64, 3, 16, act=nn.LeakyReLU(0.2, inplace=True), num_dab=2)]
        self.outBlock = nn.Sequential(*OutBlock)

        OutBlock2 = [conv(n_feats, 3, kernel_size=kernel_size, stride=1)]
        self.outBlock2 = nn.Sequential(*OutBlock2)

    def forward(self, input, detail):
        feature_in = self.FeatureBlock( input )
        detailF = self.FeatureBlock(self.Feature2(detail))
        clear_features = feature_in - detailF

        self.n_levels = 2
        self.scale = 0.5
        output = []
        for level in range(self.n_levels):
            scale = self.scale ** (self.n_levels - level - 1)
            n, c, h, w = input.shape
            hi = int(round(h * scale))
            wi = int(round(w * scale))
            if level == 0:
                input_clear = F.interpolate(clear_features, (hi, wi), mode='bilinear')
                first_scale_inblock = self.inBlock1(input_clear)
            else:
                input_clear = F.interpolate(clear_features, (hi, wi), mode='bilinear')
                input_pred = F.interpolate(input_pre, (hi, wi), mode='bilinear')
                inp_all = torch.cat((input_clear, input_pred), 1)
                first_scale_inblock = self.inBlock2(inp_all)

            first_scale_encoder_first = self.encoder_first(first_scale_inblock);
            first_scale_encoder_second = self.encoder_second(first_scale_encoder_first)
            first_scale_encoder_third = self.encoder_third( first_scale_encoder_second )
            first_scale_encoder_fourth = self.encoder_fourth(first_scale_encoder_third)

            input_pre = self.outBlock( first_scale_encoder_fourth )
            out = self.outBlock2(input_pre)
            output.append(out)
        return output

if __name__ == '__main__':
    img  = torch.randn(1, 3, 256, 256)
    net3 = DEBLUR()
    out1 = net3(img, img)


