import numpy as np
import math

def boxfilter(I, r):
    w = (1.0/r**2)*np.ones((r,r))

    #get array sizes
    ma = I.shape[0]
    na = I.shape[1]
    mb = w.shape[0]
    nb = w.shape[1]

    #To do convolution
    c = np.zeros(((ma+mb-1), (na+nb-1)))
    for i in range(mb):
        for j in range(nb):
            r1 = i
            r2 = r1 + ma -1
            c1 = j
            c2 = c1 + na -1
            c[r1:r2+1, c1:c2+1] = c[r1:r2+1, c1:c2+1] + w[i, j]*I.astype('float64')
    #extract region of size(a) from c
    r1 = math.floor(mb/2.0) + 1
    r2 = r1 + ma -1
    c1 = math.floor(nb/2.0) + 1
    c2 = c1 + na -1
    C = c[r1-1 : r2, c1-1 : c2]
    return C