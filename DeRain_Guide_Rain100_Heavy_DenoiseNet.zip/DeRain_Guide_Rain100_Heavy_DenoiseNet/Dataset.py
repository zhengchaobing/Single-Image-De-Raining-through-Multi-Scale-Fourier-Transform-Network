import torch
import torchvision
from torch.utils import data
from torch.autograd import Variable
import cv2
import numpy as np
import os
import random
import scipy.io as sio

train_len=1800
class DatasetTrain(data.Dataset):
    def __init__(self, opt):
        LowRoot = np.array([''])
        for index in range(1,train_len+1):
            file = str(index)
            LowRoot  = np.append(LowRoot, opt.train_rootL + file +'.mat')

        self.LowRoot = LowRoot[1:]
        self.opt = opt
        self.len=len(self.LowRoot)

    def transformImage(self,image):
        opt = self.opt
        image = torchvision.transforms.ToTensor()(image)
        Tensor = torch.FloatTensor if opt.device == 'cpu' else torch.cuda.FloatTensor
        image = Variable(image.type(Tensor))
        return image

    def __getitem__(self, index):
        W = 128
        H = 128
        mat = sio.loadmat(self.LowRoot[index])

        img_Rain = mat["img_Rain"].astype(np.float64)
        img_noRain = (mat["img_noRain"]).astype(np.float64)
        haze_e = mat["haze_e"].astype(np.float64)
        Hig, Wid, C = img_Rain.shape

        w_offset = random.randint(0, max(0, Wid - W - 1))
        h_offset = random.randint(0, max(0, Hig - H - 1))

        Rain   = img_Rain[h_offset:h_offset + H, w_offset:w_offset + W, :]
        noRain = img_noRain[h_offset:h_offset + H, w_offset:w_offset + W, :]
        detail = haze_e[h_offset:h_offset + H, w_offset:w_offset + W]

        Rain = self.transformImage(Rain)
        noRain = self.transformImage(noRain)
        detail = self.transformImage(detail)

        return Rain, noRain, detail

    def __len__(self):
        return int(self.len)


test_len=200
class DatasetTest(data.Dataset):
    def __init__(self, opt):
        LowRoot = np.array([''])
        for index in range(1,test_len+1):
            file = str(index)
            LowRoot  = np.append(LowRoot, opt.test_rootL + file +'.mat')

        self.LowRoot = LowRoot[1:]
        self.opt = opt
        self.len=len(self.LowRoot)

    def transformImage(self,image):
        opt = self.opt
        image = torchvision.transforms.ToTensor()(image)
        Tensor = torch.FloatTensor if opt.device == 'cpu' else torch.cuda.FloatTensor
        image = Variable(image.type(Tensor))
        return image


    def __getitem__(self, index):
        mat = sio.loadmat(self.LowRoot[index])

        img_Rain = mat["img_Rain"].astype(np.float64)
        img_noRain = (mat["img_noRain"]).astype(np.float64)
        haze_e = mat["haze_e"].astype(np.float64)

        Rain = self.transformImage(img_Rain)
        noRain = self.transformImage(img_noRain)
        detail = self.transformImage(haze_e)

        return Rain, noRain, detail

    def __len__(self):
        return int(self.len)
