###########################################################################
# Created by: CASIA IVA
# Email: jliu@nlpr.ia.ac.cn
# Copyright (c) 2018
###########################################################################

import numpy as np
import torch
import math
from torch.nn import Module, Sequential, Conv2d, ReLU,AdaptiveMaxPool2d, AdaptiveAvgPool2d, \
    NLLLoss, BCELoss, CrossEntropyLoss, AvgPool2d, MaxPool2d, Parameter, Linear, Sigmoid, Softmax, Dropout, Embedding
from torch.nn import functional as F
from torch.autograd import Variable
torch_ver = torch.__version__[:3]
import torch.nn as nn

__all__ = ['PAM_Module', 'CAM_Module']

def conv(in_channels, out_channels, kernel_size, bias=True, padding = 1, stride = 1):
    return nn.Conv2d(in_channels, out_channels, kernel_size, padding=(kernel_size//2),  bias=bias, stride = stride)


## channel attention modules
class CALayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
            nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
            nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y


## spatial  attention
class spatial_attn_layer(nn.Module):
    def __init__(self, kernel_size=3):
        super(spatial_attn_layer, self).__init__()
        self.compress = ChannelPool()
        self.spatial = BasicConv(2, 1, kernel_size, stride=1, padding=(kernel_size - 1) // 2, relu=False)

    def forward(self, x):
        # import pdb;pdb.set_trace()
        x_compress = self.compress(x)
        x_out = self.spatial(x_compress)
        scale = torch.sigmoid(x_out)  # broadcasting
        return x * scale
        ##########################################################################


###BasicConv
class BasicConv(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1, groups=1, relu=True,
                 bn=False, bias=False):
        super(BasicConv, self).__init__()
        self.out_channels = out_planes
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding,
                              dilation=dilation, groups=groups, bias=bias)
        self.bn = nn.BatchNorm2d(out_planes, eps=1e-5, momentum=0.01, affine=True) if bn else None
        self.relu = nn.LeakyReLU(0.2, inplace=True) if relu else None

    def forward(self, x):
        x = self.conv(x)
        if self.bn is not None:
            x = self.bn(x)
        if self.relu is not None:
            x = self.relu(x)
        return x


###ChannelPool
class ChannelPool(nn.Module):
    def forward(self, x):
        return torch.cat((torch.max(x, 1)[0].unsqueeze(1), torch.mean(x, 1).unsqueeze(1)), dim=1)


## Dual Attention Block (DAB)
class DAB(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction, bias=True, bn=False, act=nn.PReLU(64)):

        super(DAB, self).__init__()
        modules_body = []
        for i in range(2):
            modules_body.append(conv(n_feat, n_feat, kernel_size, bias=bias))
            if bn: modules_body.append(nn.BatchNorm2d(n_feat))
            if i == 0: modules_body.append(act)

        self.SA = spatial_attn_layer()  ## Spatial Attention
        self.CA = CALayer(n_feat, reduction)  ## Channel Attention
        self.body = nn.Sequential(*modules_body)
        self.conv1x1 = nn.Conv2d(n_feat * 2, n_feat, kernel_size=1)

    def forward(self, x):
        res = self.body(x)
        sa_branch = self.SA(res)
        ca_branch = self.CA(res)
        res = torch.cat([sa_branch, ca_branch], dim=1)
        res = self.conv1x1(res)
        res += x
        return res


## Recursive Residual Group (RRG)
class RRG(nn.Module):
    def __init__(self, conv, n_feat, kernel_size, reduction, act, num_dab):
        super(RRG, self).__init__()
        modules_body = [
            DAB(conv, n_feat, kernel_size, reduction, bias=True, bn=True, act=nn.LeakyReLU(0.2, inplace=True)) for _ in
            range(num_dab)]
        modules_body.append(conv(n_feat, n_feat, kernel_size))
        self.body = nn.Sequential(*modules_body)

    def forward(self, x):
        res = self.body(x)
        res += x
        return res

#####DenoiseNet
class DeRainNet(nn.Module):
    def __init__(self, conv=conv):
        super(DeRainNet, self).__init__()
        num_rrg  = 4
        num_dab  = 6
        n_feats  = 64
        kernel_size = 3
        reduction = 16
        inp_chans = 3
        act = nn.PReLU(n_feats)
        ######################################################################################
        ######################################################################################
        layers1A=[conv(n_feats, n_feats, kernel_size=kernel_size, stride=1)];
        layers1A.append(act)
        layers1A.append(conv(n_feats, n_feats, kernel_size=kernel_size, stride=1));
        self.dncnn1A = nn.Sequential(*layers1A)

        layers2A=[conv(n_feats, n_feats, kernel_size=kernel_size, stride=1)];
        layers2A.append(act)
        layers2A.append(conv(n_feats, n_feats, kernel_size=kernel_size, stride=1));
        self.dncnn2A = nn.Sequential(*layers2A)

        layers3A=[conv(n_feats, n_feats, kernel_size=kernel_size, stride=1)];
        layers3A.append(act)
        layers3A.append(conv(n_feats, n_feats, kernel_size=kernel_size, stride=1));
        self.dncnn3A = nn.Sequential(*layers3A)

        layers4A=[conv(n_feats, n_feats, kernel_size=kernel_size, stride=1)];
        layers4A.append(act)
        layers4A.append(conv(n_feats, n_feats, kernel_size=kernel_size, stride=1));
        self.dncnn4A = nn.Sequential(*layers4A)
        ######################################################################################
        ######################################################################################


        modules_head1 = [conv(inp_chans, n_feats, kernel_size=kernel_size, stride=1)]
        modules_head2 = [conv(inp_chans, n_feats, kernel_size=kernel_size, stride=1)]

        modules_body1 = [RRG(conv, n_feats, kernel_size, reduction, act=act, num_dab=num_dab)]
        modules_body2 = [RRG(conv, n_feats, kernel_size, reduction, act=act, num_dab=num_dab)]
        modules_body3 = [RRG(conv, n_feats, kernel_size, reduction, act=act, num_dab=num_dab)]
        modules_body4 = [RRG(conv, n_feats, kernel_size, reduction, act=act, num_dab=num_dab)]
        modules_body=[conv(n_feats, n_feats, kernel_size)]

        modules_body.append(act)

        modules_tail = [conv(n_feats, inp_chans, kernel_size)]

        self.head1 = nn.Sequential(*modules_head1)
        self.head2 = nn.Sequential(*modules_head2)

        self.body1 = nn.Sequential(*modules_body1)
        self.body2 = nn.Sequential(*modules_body2)
        self.body3 = nn.Sequential(*modules_body3)
        self.body4 = nn.Sequential(*modules_body4)

        self.body = nn.Sequential(*modules_body)

        self.tail = nn.Sequential(*modules_tail)

        self.lamb1 = Parameter(torch.ones(1), requires_grad=True)
        self.lamb2 = Parameter(torch.ones(1), requires_grad=True)
        self.lamb3 = Parameter(torch.ones(1), requires_grad=True)
        self.lamb4 = Parameter(torch.ones(1), requires_grad=True)

    def forward(self, image, Detail):
        x1  = self.head1(image);     x2  = self.head2(Detail)

        x1A = self.body1(x1);        x1B = self.dncnn1A(x2);   Add1 = x1B * self.lamb1 + x1A;

        x2A = self.body2(Add1);      x2B = self.dncnn2A(x1B);  Add2 = x2B * self.lamb2 + x2A;

        x3A = self.body3(Add2);      x3B = self.dncnn3A(x2B);  Add3 = x3B * self.lamb3 + x3A;

        x4A = self.body4(Add3);      x4B = self.dncnn4A(x3B);  Add4 = x4B * self.lamb4 + x4A;

        x = self.body(Add4);
        x = self.tail(x)
        x = image + x
        x = torch.clamp(x, 0.0, 1.0)
        return x


if __name__ == '__main__':
    img  = torch.randn(1, 3, 256, 256)
    net3 = DeRainNet()
    out1 = net3(img)
    print(out1.size())

